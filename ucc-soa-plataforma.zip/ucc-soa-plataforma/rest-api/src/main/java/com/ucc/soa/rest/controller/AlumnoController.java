package com.ucc.soa.rest.controller;

import com.ucc.soa.rest.entity.Alumno;
import com.ucc.soa.rest.repository.AlumnoRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/alumnos")
public class AlumnoController {

    private final AlumnoRepository alumnoRepository;

    public AlumnoController(AlumnoRepository alumnoRepository) {
        this.alumnoRepository = alumnoRepository;
    }

    @GetMapping
    public List<Alumno> getAll() {
        return alumnoRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Alumno> getById(@PathVariable Long id) {
        return alumnoRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Alumno create(@RequestBody Alumno alumno) {
        return alumnoRepository.save(alumno);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Alumno> update(
            @PathVariable Long id,
            @RequestBody Alumno body
    ) {
        return alumnoRepository.findById(id)
                .map(existing -> {
                    existing.setNombre(body.getNombre());
                    existing.setEmail(body.getEmail());
                    existing.setCarrera(body.getCarrera());
                    return ResponseEntity.ok(alumnoRepository.save(existing));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (!alumnoRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        alumnoRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
