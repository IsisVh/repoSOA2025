package com.ucc.soa.rest.controller;

import com.ucc.soa.rest.entity.Alumno;
import com.ucc.soa.rest.entity.Calificacion;
import com.ucc.soa.rest.repository.AlumnoRepository;
import com.ucc.soa.rest.repository.CalificacionRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/calificaciones")
public class CalificacionController {

    private final CalificacionRepository calificacionRepository;
    private final AlumnoRepository alumnoRepository;

    public CalificacionController(CalificacionRepository calificacionRepository,
                                  AlumnoRepository alumnoRepository) {
        this.calificacionRepository = calificacionRepository;
        this.alumnoRepository = alumnoRepository;
    }

    @GetMapping
    public List<Calificacion> getAll() {
        return calificacionRepository.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Calificacion> getById(@PathVariable Long id) {
        return calificacionRepository.findById(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ResponseEntity<?> create(@RequestBody Map<String, String> body) {
        try {
            Long alumnoId = Long.parseLong(body.get("alumnoId"));
            String materia = body.get("materia");
            Double calificacionValor = Double.parseDouble(body.get("calificacion"));
            LocalDate fecha = LocalDate.parse(body.get("fecha"));

            Alumno alumno = alumnoRepository.findById(alumnoId)
                    .orElseThrow(() -> new IllegalArgumentException("Alumno no encontrado"));

            Calificacion calificacion = new Calificacion(alumno, materia, calificacionValor, fecha);
            return ResponseEntity.ok(calificacionRepository.save(calificacion));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error al crear la calificación: " + e.getMessage());
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> update(@PathVariable Long id, @RequestBody Map<String, String> body) {
        return calificacionRepository.findById(id)
                .map(existing -> {
                    if (body.containsKey("materia")) {
                        existing.setMateria(body.get("materia"));
                    }
                    if (body.containsKey("calificacion")) {
                        existing.setCalificacion(Double.parseDouble(body.get("calificacion")));
                    }
                    if (body.containsKey("fecha")) {
                        existing.setFecha(LocalDate.parse(body.get("fecha")));
                    }
                    return ResponseEntity.ok(calificacionRepository.save(existing));
                })
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> delete(@PathVariable Long id) {
        if (!calificacionRepository.existsById(id)) {
            return ResponseEntity.notFound().build();
        }
        calificacionRepository.deleteById(id);
        return ResponseEntity.noContent().build();
    }
}
