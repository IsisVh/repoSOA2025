package com.ucc.soa.rest.repository;

import com.ucc.soa.rest.entity.Calificacion;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CalificacionRepository extends JpaRepository<Calificacion, Long> {
}
